This was created in 1 week using C++, OpenGL/ GLEW, SFML and GLM libs.

The performance, CPU usage, etc is not optimal, but this is what I managed to get done in a week.

The code is open source, and can be found at: https://github.com/Hopson97/MineCraft-One-Week-Challenge

You can change various settings using the config.txt file that looks like this:


| renderdistance 16
| fullscreen 0
| windowsize 1280 720
| fov 145
